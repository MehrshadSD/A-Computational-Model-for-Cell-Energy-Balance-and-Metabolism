% clear all

eps = 0.01;
jacobi = zeros(8,15);
jrow = 1;

global_par_IRS_p_phos_by_p70_S6K_pT229_pT389=0.338859859949792;
global_par_IRS_phos_by_p70_S6K_pT229_pT389=0.0863775267376444;
global_par_Akt_S473_phos_by_mTORC2_pS2481_first=1.31992E-5;
global_par_Akt_S473_phos_by_mTORC2_pS2481_second=0.159093;
global_par_Akt_T308_phos_by_PI3K_p_PDK1_first=7.47437;
global_par_Akt_T308_phos_by_PI3K_p_PDK1_second=7.47345;
global_par_TSC1_TSC2_S1387_phos_by_AMPK_pT172=0.00175772;
global_par_TSC1_TSC2_T1462_phos_by_Akt_pT308=1.52417;
global_par_mTORC1_pS2448_dephos_by_TSC1_TSC2=0.00869774;
global_par_mTORC2_S2481_phos_by_PI3K_variant_p=0.120736;
global_par_p70_S6K_T389_phos_by_mTORC1_pS2448_first=0.00261303413778722;
global_par_p70_S6K_T389_phos_by_mTORC1_pS2448_second=0.110720890919343;
global_par_PRAS40_S183_phos_by_mTORC1_pS2448_first=0.15881;
global_par_PRAS40_S183_phos_by_mTORC1_pS2448_second=0.0683009;
global_par_PRAS40_T246_phos_by_Akt_pT308_first=0.279344;
global_par_PRAS40_T246_phos_by_Akt_pT308_second=0.279401;
global_par_PI3K_PDK1_phos_by_IRS_p=1.87226757782201E-4;
global_par_PI3K_variant_phos_by_IR_beta_pY1146=5.49027801822575E-4;
global_par_AMPK_T172_phos=0.490602;
global_par_AMPK_SIRT=1e7;
global_par_mTORC1_pS2481_by_PRAS40=0.00068;
global_Kcat_NamPRT = 0.0077;
global_Km_NamPRT   = 5e-6;
global_NAMPT_AMPT  = 0.2;
global_SIRT_Kcat = 0.67;  
global_SIRT_Km = 0.029;  
global_SIRT_Ki = 0.06;  
global_NADA_Kcat = 0.69;
    
legends_SS
[IRS_p_base AMPK_pT172_base Akt_pT308_pS473_base TSC1_TSC2_base mTORC1_pS2448_base mTORC2_pS2481_base p70_S6K_pT229_pT389_base PRAS40_base PI3K_p_PDK1_base SIRT_base NAM_base NMN_base NAD_base NAMPT_base ULK1s_base] = get_measures(x(end,:));

% take derivative w.r.t. S6Kpp->IRSpp
tmp = global_par_IRS_p_phos_by_p70_S6K_pT229_pT389;
global_par_IRS_p_phos_by_p70_S6K_pT229_pT389 = global_par_IRS_p_phos_by_p70_S6K_pT229_pT389*(1+eps);
legends_SS
global_par_IRS_p_phos_by_p70_S6K_pT229_pT389 = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. S6Kpp->IRSp
tmp = global_par_IRS_phos_by_p70_S6K_pT229_pT389;
global_par_IRS_phos_by_p70_S6K_pT229_pT389 = global_par_IRS_phos_by_p70_S6K_pT229_pT389*(1+eps);
legends_SS
global_par_IRS_phos_by_p70_S6K_pT229_pT389 = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. mTORC2->Aktpp
tmp = global_par_Akt_S473_phos_by_mTORC2_pS2481_first;
global_par_Akt_S473_phos_by_mTORC2_pS2481_first = global_par_Akt_S473_phos_by_mTORC2_pS2481_first*(1+eps);
legends_SS
global_par_Akt_S473_phos_by_mTORC2_pS2481_first = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. mTORC2->Aktpp, a second reaction
tmp = global_par_Akt_S473_phos_by_mTORC2_pS2481_second;
global_par_Akt_S473_phos_by_mTORC2_pS2481_second = global_par_Akt_S473_phos_by_mTORC2_pS2481_second*(1+eps);
legends_SS
global_par_Akt_S473_phos_by_mTORC2_pS2481_second = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. PI3K PDK1->Aktp, a second reaction
tmp = global_par_Akt_T308_phos_by_PI3K_p_PDK1_first;
global_par_Akt_T308_phos_by_PI3K_p_PDK1_first = global_par_Akt_T308_phos_by_PI3K_p_PDK1_first*(1+eps);
legends_SS
global_par_Akt_T308_phos_by_PI3K_p_PDK1_first = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. PI3K PDK1->Aktp, a second reaction
tmp = global_par_Akt_T308_phos_by_PI3K_p_PDK1_second;
global_par_Akt_T308_phos_by_PI3K_p_PDK1_second = global_par_Akt_T308_phos_by_PI3K_p_PDK1_second*(1+eps);
legends_SS
global_par_Akt_T308_phos_by_PI3K_p_PDK1_second = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. AMPK->TSC1-TSC2 S1387
tmp = global_par_TSC1_TSC2_S1387_phos_by_AMPK_pT172;
global_par_TSC1_TSC2_S1387_phos_by_AMPK_pT172 = global_par_TSC1_TSC2_S1387_phos_by_AMPK_pT172*(1+eps);
legends_SS
global_par_TSC1_TSC2_S1387_phos_by_AMPK_pT172 = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. Akt->TSC1-TSC2 T308
tmp = global_par_TSC1_TSC2_T1462_phos_by_Akt_pT308;
global_par_TSC1_TSC2_T1462_phos_by_Akt_pT308 = global_par_TSC1_TSC2_T1462_phos_by_Akt_pT308*(1+eps);
legends_SS
global_par_TSC1_TSC2_T1462_phos_by_Akt_pT308 = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. TSC1-TSC2->mTORC1 S2448
tmp = global_par_mTORC1_pS2448_dephos_by_TSC1_TSC2;
global_par_mTORC1_pS2448_dephos_by_TSC1_TSC2 = global_par_mTORC1_pS2448_dephos_by_TSC1_TSC2*(1+eps);
legends_SS
global_par_mTORC1_pS2448_dephos_by_TSC1_TSC2 = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. PI3K->mTORC2 S2481
tmp = global_par_mTORC2_S2481_phos_by_PI3K_variant_p;
global_par_mTORC2_S2481_phos_by_PI3K_variant_p = global_par_mTORC2_S2481_phos_by_PI3K_variant_p*(1+eps);
legends_SS
global_par_mTORC2_S2481_phos_by_PI3K_variant_p = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. mTORC1->S6K
tmp = global_par_p70_S6K_T389_phos_by_mTORC1_pS2448_first;
global_par_p70_S6K_T389_phos_by_mTORC1_pS2448_first = global_par_p70_S6K_T389_phos_by_mTORC1_pS2448_first*(1+eps);
legends_SS
global_par_p70_S6K_T389_phos_by_mTORC1_pS2448_first = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;
    
% take derivative w.r.t. also mTORC1->S6K but a second reaction
tmp = global_par_p70_S6K_T389_phos_by_mTORC1_pS2448_second;
global_par_p70_S6K_T389_phos_by_mTORC1_pS2448_second = global_par_p70_S6K_T389_phos_by_mTORC1_pS2448_second*(1+eps);
legends_SS
global_par_p70_S6K_T389_phos_by_mTORC1_pS2448_second = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. mTORC1->PRAS40
tmp = global_par_PRAS40_S183_phos_by_mTORC1_pS2448_first;
global_par_PRAS40_S183_phos_by_mTORC1_pS2448_first = global_par_PRAS40_S183_phos_by_mTORC1_pS2448_first*(1+eps);
legends_SS
global_par_PRAS40_S183_phos_by_mTORC1_pS2448_first = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;
    
% take derivative w.r.t. mTORC1->PRAS40, second reaction
tmp = global_par_PRAS40_S183_phos_by_mTORC1_pS2448_second;
global_par_PRAS40_S183_phos_by_mTORC1_pS2448_second = global_par_PRAS40_S183_phos_by_mTORC1_pS2448_second*(1+eps);
legends_SS
global_par_PRAS40_S183_phos_by_mTORC1_pS2448_second = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. Akt->PRAS40
tmp = global_par_PRAS40_T246_phos_by_Akt_pT308_first;
global_par_PRAS40_T246_phos_by_Akt_pT308_first = global_par_PRAS40_T246_phos_by_Akt_pT308_first*(1+eps);
legends_SS
global_par_PRAS40_T246_phos_by_Akt_pT308_first = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. Akt->PRAS40, second reaction
tmp = global_par_PRAS40_T246_phos_by_Akt_pT308_second;
global_par_PRAS40_T246_phos_by_Akt_pT308_second = global_par_PRAS40_T246_phos_by_Akt_pT308_second*(1+eps);
legends_SS
global_par_PRAS40_T246_phos_by_Akt_pT308_second = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. IRSp->PI3K PDK1
tmp = global_par_PI3K_PDK1_phos_by_IRS_p;
global_par_PI3K_PDK1_phos_by_IRS_p = global_par_PI3K_PDK1_phos_by_IRS_p*(1+eps);
legends_SS
global_par_PI3K_PDK1_phos_by_IRS_p = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. IRS beta p->PI3K variant
tmp = global_par_PI3K_variant_phos_by_IR_beta_pY1146;
global_par_PI3K_variant_phos_by_IR_beta_pY1146 = global_par_PI3K_variant_phos_by_IR_beta_pY1146*(1+eps);
legends_SS
global_par_PI3K_variant_phos_by_IR_beta_pY1146 = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. NAM->NAMPT
tmp = global_par_AMPK_T172_phos;
global_par_AMPK_T172_phos = global_par_AMPK_T172_phos*(1+eps);
legends_SS
global_par_AMPK_T172_phos = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. SIRT activation of AMPK
tmp = global_par_AMPK_SIRT;
global_par_AMPK_SIRT = global_par_AMPK_SIRT*(1+eps);
legends_SS
global_par_AMPK_SIRT = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. PRAS40 inhibition of mTORC1
tmp = global_par_mTORC1_pS2481_by_PRAS40;
global_par_mTORC1_pS2481_by_PRAS40 = global_par_mTORC1_pS2481_by_PRAS40*(1+eps);
legends_SS
global_par_mTORC1_pS2481_by_PRAS40 = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. NAM->NAMPT
tmp = global_Kcat_NamPRT;
global_Kcat_NamPRT = global_Kcat_NamPRT*(1+eps);
legends_SS
global_Kcat_NamPRT = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. NAM->NAMPT
tmp = global_Km_NamPRT;
global_Km_NamPRT = global_Km_NamPRT*(1+eps);
legends_SS
global_Km_NamPRT = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. AMPK->NAMPT
tmp = global_NAMPT_AMPT;
global_NAMPT_AMPT = global_NAMPT_AMPT*(1+eps);
legends_SS
global_NAMPT_AMPT = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. AMPK->SIRT
tmp = global_SIRT_Kcat;
global_SIRT_Kcat = global_SIRT_Kcat*(1+eps);
legends_SS
global_SIRT_Kcat = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% take derivative w.r.t. AMPK->SIRT
tmp = global_SIRT_Km;
global_SIRT_Km = global_SIRT_Km*(1+eps);
legends_SS
global_SIRT_Km = tmp;
[IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
        (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
        (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
        (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
jrow = jrow+1;

% % take derivative w.r.t. AMPK->SIRT
% tmp = global_SIRT_Ki;
% global_SIRT_Ki = global_SIRT_Ki*(1+eps);
% legends_SS
% global_SIRT_Ki = tmp;
% [IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
% jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
%         (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
%         (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
%         (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
% jrow = jrow+1;
% 
% % take derivative w.r.t. NAM->NA rate
% tmp = global_NADA_Kcat;
% global_NADA_Kcat = global_NADA_Kcat*(1+eps);
% legends_SS
% global_NADA_Kcat = tmp;
% [IRS_p_inc AMPK_pT172_inc Akt_pT308_pS473_inc TSC1_TSC2_inc mTORC1_pS2448_inc mTORC2_pS2481_inc p70_S6K_pT229_pT389_inc PRAS40_inc PI3K_p_PDK1_inc SIRT_inc NAM_inc NMN_inc NAD_inc NAMPT_inc ULK1s_inc] = get_measures(x(end,:));
% jacobi(jrow,:) = [(IRS_p_inc./IRS_p_base-1)/eps, (AMPK_pT172_inc./AMPK_pT172_base-1)/eps, (Akt_pT308_pS473_inc./Akt_pT308_pS473_base-1)/eps, (TSC1_TSC2_inc./TSC1_TSC2_base-1)/eps, ...
%         (mTORC1_pS2448_inc./mTORC1_pS2448_base-1)/eps, (mTORC2_pS2481_inc./mTORC2_pS2481_base-1)/eps, (p70_S6K_pT229_pT389_inc./p70_S6K_pT229_pT389_base-1)/eps, ...
%         (PRAS40_inc./PRAS40_base-1)/eps, (PI3K_p_PDK1_inc./PI3K_p_PDK1_base-1)/eps, (ULK1s_inc./ULK1s_base-1)/eps, ...
%         (SIRT_inc./SIRT_base-1)/eps, (NAM_inc./NAM_base-1)/eps, (NMN_inc./NMN_base-1)/eps, (NAD_inc./NAD_base-1)/eps, (NAMPT_inc./NAMPT_base-1)/eps];
% jrow = jrow+1;

%%% display Jacobian matrix
jacobi
xvalues = {'IRS\_p','AMPK\_pT172','Akt\_pT308\_pS473','TSC1\_TSC2','mTORC1\_pS2448','mTORC2\_pS2481','p70S6K\_pT229\_pT389','PRAS40','PI3K\_p\_PDK1','Act ULK1','SIRT','NAM','NMN','NAD','NAMPT'};
yvalues = {'par\_IRS\_p\_phos\_by\_p70\_S6K\_pT229\_pT389','par\_IRS\_phos\_by\_p70\_S6K\_pT229\_pT389', ...
    'par\_Akt\_S473\_phos\_by\_mTORC2\_pS2481\_first','par\_Akt\_S473\_phos\_by\_mTORC2\_pS2481\_second', ...
    'par\_Akt\_T308\_phos\_by\_PI3K\_p\_PDK1\_first','par\_Akt\_T308\_phos\_by\_PI3K\_p\_PDK1\_second', ...
    'par\_TSC1\_TSC2\_S1387\_phos\_by\_AMPK\_pT172','par\_TSC1\_TSC2\_T1462\_phos\_by\_Akt\_pT308', ...
    'par\_mTORC1\_pS2448\_dephos\_by\_TSC1\_TSC2','par\_mTORC2\_S2481\_phos\_by\_PI3K\_variant\_p', ...
    'p70\_S6K\_T389\_phos\_by\_mTORC1\_pS2448\_first','p70\_S6K\_T389\_phos\_by\_mTORC1\_pS2448\_second', ...
    'par\_PRAS40\_S183\_phos\_by\_mTORC1\_pS2448\_first','par\_PRAS40\_S183\_phos\_by\_mTORC1\_pS2448\_second', ...
    'par\_PRAS40\_T246\_phos\_by\_Akt\_pT308\_first','par\_PRAS40\_T246\_phos\_by\_Akt\_pT308\_second', ...
    'par\_PI3K\_PDK1\_phos\_by\_IRS\_p','par\_PI3K\_variant\_phos\_by\_IR\_beta\_pY1146', ...
    'par\_AMPK\_T172\_phos','par\_AMPK\_SIRT','par\_mTORC1\_pS2481\_by\_PRAS40', ...
    'Kcat\_NamPT','Km\_NamPT','NAMPT\_AMPT','SIRT\_Kcat','SIRT\_Km'};
h = heatmap(xvalues,yvalues,jacobi,'CellLabelColor','none','Colormap',parula,'Fontsize',14)


function [IRS_p AMPK_pT172 Akt_pT308_pS473 TSC1_TSC2 mTORC1_pS2448 mTORC2_pS2481 p70_S6K_pT229_pT389 PRAS40 PI3K_p_PDK1 SIRT NAM NMN NAD NAMPT ULK1s] = get_measures (x)
    
    IRS_p         = x(:,5);
    AMPK_pT172    = x(8);
    Akt_pT308_pS473 = x(12);
    TSC1_TSC2     = x(:,13);
    mTORC1_pS2448 = x(17);
    mTORC2_pS2481 = x(:,19);
    p70_S6K_pT229_pT389 = x(23);
    PRAS40        = x(:,24);
    PI3K_p_PDK1   = x(:,31);
    SIRT   = x(56);
    NAM    = x(53);
    NMN    = x(50);
    NAD    = x(54);
    NAMPT  = x(69);
    ULK1s  = x(61);

end
