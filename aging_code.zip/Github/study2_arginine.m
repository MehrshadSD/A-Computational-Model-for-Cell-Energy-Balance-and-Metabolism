clear all

leucine_conc = 0.1;
sestrine_conc= 0.1;
exp_num = 1;

arginine = 0;
legends_AA
mTORC1_pS2448_arg0 = x(:,17);
p70_S6K_pT389_arg0       = x(:,22);
ULK1s_arg0         = x(:,61);
AMPK_pT172_arg0 = x(:,8);
IRS_p_arg0         = x(:,5);
t_arg0             = t;
% supplement
mTORC2_pS2481_arg0       = x(:,19);
PRAS40_pS183_arg0        = x(:,26);
p70_S6K_pT229_pT389_arg0 = x(:,23);
IRS_p_arg0               = x(:,5);
Akt_pT308_arg0           = x(:,10);
TSC1_TSC2_pT1462_arg0    = x(:,14);

arginine = 0.25;
legends_AA
mTORC1_pS2448_arg25 = x(:,17);
p70_S6K_pT389_arg25       = x(:,22);
ULK1s_arg25         = x(:,61);
AMPK_pT172_arg25 = x(:,8);
IRS_p_arg25         = x(:,5);
t_arg25             = t;
% supplement
mTORC2_pS2481_arg25       = x(:,19);
PRAS40_pS183_arg25        = x(:,26);
p70_S6K_pT229_pT389_arg25 = x(:,23);
IRS_p_arg25               = x(:,5);
Akt_pT308_arg25           = x(:,10);
TSC1_TSC2_pT1462_arg25    = x(:,14);

arginine = 0.5;
legends_AA
mTORC1_pS2448_arg5 = x(:,17);
p70_S6K_pT389_arg5       = x(:,22);
ULK1s_arg5         = x(:,61);
AMPK_pT172_arg5 = x(:,8);
IRS_p_arg5         = x(:,5);
t_arg5             = t;
% supplement
mTORC2_pS2481_arg5       = x(:,19);
PRAS40_pS183_arg5        = x(:,26);
p70_S6K_pT229_pT389_arg5 = x(:,23);
IRS_p_arg5               = x(:,5);
Akt_pT308_arg5           = x(:,10);
TSC1_TSC2_pT1462_arg5    = x(:,14);

arginine = 1;
legends_AA
mTORC1_pS2448_arg1 = x(:,17);
p70_S6K_pT389_arg1       = x(:,22);
ULK1s_arg1         = x(:,61);
AMPK_pT172_arg1 = x(:,8);
IRS_p_arg1         = x(:,5);
t_arg1             = t;
% supplement
mTORC2_pS2481_arg1       = x(:,19);
PRAS40_pS183_arg1        = x(:,26);
p70_S6K_pT229_pT389_arg1 = x(:,23);
IRS_p_arg1               = x(:,5);
Akt_pT308_arg1           = x(:,10);
TSC1_TSC2_pT1462_arg1    = x(:,14);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
t0 = 1; tf = 480;
figure(1), clf

subplot(3,1,1) 
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg0(ind)-t0,mTORC1_pS2448_arg0(ind),'-k','Linewidth',2);
hold on
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg5(ind)-t0,mTORC1_pS2448_arg25(ind),'-r','Linewidth',2);
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg25(ind)-t0,mTORC1_pS2448_arg5(ind),'-g','Linewidth',2);
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg1(ind)-t0,mTORC1_pS2448_arg1(ind),'-b','Linewidth',2);
set(gca,'Fontsize',14)
ylabel('mTORC1\_pS2448','Fontsize',16)
xlabel('Time (min)','Fontsize',16)
legend('No Arginine','Low Arginine','Medium Arginine','High Arginine','Fontsize',14,'Location','east')
axis tight

% subplot(3,1,2)
% ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg0(ind)-t0,p70_S6K_pT389_arg0(ind),'-k','Linewidth',2);
% hold on
% ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg5(ind)-t0,p70_S6K_pT389_arg5(ind),'-r','Linewidth',2);
% ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg25(ind)-t0,p70_S6K_pT389_arg25(ind),'-g','Linewidth',2);
% ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg1(ind)-t0,p70_S6K_pT389_arg1(ind),'-b','Linewidth',2);
% set(gca,'Fontsize',14)
% title('B:  p70 S6K pT389','Fontsize',16)
% legend('No Arginine','Low Arginine','Medium Arginine','High Arginine','Fontsize',14,'Location','east')
% axis tight

subplot(3,1,2)
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg0(ind)-t0,ULK1s_arg0(ind),'-k','Linewidth',2);
% ylim([0 5])
hold on
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg5(ind)-t0,ULK1s_arg25(ind),'-r','Linewidth',2);
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg25(ind)-t0,ULK1s_arg5(ind),'-g','Linewidth',2);
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg1(ind)-t0,ULK1s_arg1(ind),'-b','Linewidth',2);
set(gca,'Fontsize',14)
ylabel('Act ULK1','Fontsize',16)
xlabel('Time (min)','Fontsize',16)
axis tight

subplot(3,1,3)
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg0(ind)-t0,AMPK_pT172_arg0(ind),'-k','Linewidth',2);
% ylim([0 5])
hold on
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg5(ind)-t0,AMPK_pT172_arg25(ind),'-r','Linewidth',2);
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg5(ind)-t0,AMPK_pT172_arg5(ind),'-g','Linewidth',2);
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg1(ind)-t0,AMPK_pT172_arg1(ind),'-b','Linewidth',2);
set(gca,'Fontsize',14)
ylabel('AMPK\_pT172','Fontsize',16)
xlabel('Time (min)','Fontsize',16)
axis tight

% supplement
figure(2)

subplot(3,2,1) 
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg0(ind)-t0,mTORC2_pS2481_arg0(ind),'-k','Linewidth',2);
hold on
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg5(ind)-t0,mTORC2_pS2481_arg25(ind),'-r','Linewidth',2);
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg25(ind)-t0,mTORC2_pS2481_arg5(ind),'-g','Linewidth',2);
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg1(ind)-t0,mTORC2_pS2481_arg1(ind),'-b','Linewidth',2);
set(gca,'Fontsize',14)
title('A:  mTORC2 pS2481','Fontsize',16)
legend('No Arginine','Low Arginine','Medium Arginine','High Arginine','Fontsize',14,'Location','east')
axis tight

subplot(3,2,2) 
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg0(ind)-t0,PRAS40_pS183_arg0(ind),'-k','Linewidth',2);
hold on
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg5(ind)-t0,PRAS40_pS183_arg25(ind),'-r','Linewidth',2);
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg25(ind)-t0,PRAS40_pS183_arg5(ind),'-g','Linewidth',2);
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg1(ind)-t0,PRAS40_pS183_arg1(ind),'-b','Linewidth',2);
set(gca,'Fontsize',14)
title('B:  PRAS40 pS183','Fontsize',16)
% legend('No Arginine','Low Arginine','Medium Arginine','High Arginine','Fontsize',14,'Location','east')
axis tight

subplot(3,2,3) 
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg0(ind)-t0,p70_S6K_pT229_pT389_arg0(ind),'-k','Linewidth',2);
hold on
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg5(ind)-t0,p70_S6K_pT229_pT389_arg25(ind),'-r','Linewidth',2);
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg25(ind)-t0,p70_S6K_pT229_pT389_arg5(ind),'-g','Linewidth',2);
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg1(ind)-t0,p70_S6K_pT229_pT389_arg1(ind),'-b','Linewidth',2);
set(gca,'Fontsize',14)
title('C:  p70 S6K pT229 pT389','Fontsize',16)
% legend('No Arginine','Low Arginine','Medium Arginine','High Arginine','Fontsize',14,'Location','east')
axis tight

subplot(3,2,4) 
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg0(ind)-t0,IRS_p_arg0(ind),'-k','Linewidth',2);
hold on
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg5(ind)-t0,IRS_p_arg25(ind),'-r','Linewidth',2);
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg25(ind)-t0,IRS_p_arg5(ind),'-g','Linewidth',2);
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg1(ind)-t0,IRS_p_arg1(ind),'-b','Linewidth',2);
set(gca,'Fontsize',14)
title('D:  IRS p','Fontsize',16)
% legend('No Arginine','Low Arginine','Medium Arginine','High Arginine','Fontsize',14,'Location','east')
axis tight

subplot(3,2,5) 
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg0(ind)-t0,Akt_pT308_arg0(ind),'-k','Linewidth',2);
hold on
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg5(ind)-t0,Akt_pT308_arg25(ind),'-r','Linewidth',2);
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg25(ind)-t0,Akt_pT308_arg5(ind),'-g','Linewidth',2);
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg1(ind)-t0,Akt_pT308_arg1(ind),'-b','Linewidth',2);
set(gca,'Fontsize',14)
title('E:  Akt pT308','Fontsize',16)
% legend('No Arginine','Low Arginine','Medium Arginine','High Arginine','Fontsize',14,'Location','east')
axis tight

subplot(3,2,6) 
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg0(ind)-t0,TSC1_TSC2_pT1462_arg0(ind),'-k','Linewidth',2);
hold on
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg5(ind)-t0,TSC1_TSC2_pT1462_arg25(ind),'-r','Linewidth',2);
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg25(ind)-t0,TSC1_TSC2_pT1462_arg5(ind),'-g','Linewidth',2);
ind = find(t0<t_arg0&t_arg0<tf); plot(t_arg1(ind)-t0,TSC1_TSC2_pT1462_arg1(ind),'-b','Linewidth',2);
set(gca,'Fontsize',14)
title('F:  TSC1 TSC2 pT1462','Fontsize',16)
% legend('No Arginine','Low Arginine','Medium Arginine','High Arginine','Fontsize',14,'Location','east')
axis tight