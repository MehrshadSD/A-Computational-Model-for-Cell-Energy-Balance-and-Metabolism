clear all

glucose_tolerance = 0;  % not doing glucose tolerance test

% Base case with PRAS-mTORC1 link
% set parameters
akt_scaling = 1;
mtorc1_scaling = 1;
mtorc2_scaling = 1;
pi3K_pdk_scaling = 1;
b_pras_mtorc1 = 1;
base_fig_num = 0;
% execute the script
legends
% save variables
t_base_wl = t;
IRS_p_base_wl  = x(:,5);
Akt_pT308_base_wl  = x(:,10);
Akt_pS473_base_wl  = x(:,11);
Akt_pT308_pS473_base_wl = x(:,12);
mTORC1_pS2448_base_wl   = x(:,17);
mTORC2_pS2481_base_wl   = x(:,19);
PRAS40_base_wl          = x(:,24); 
PI3K_p_PDK1_base_wl     = x(:,31);
p70_S6K_pT389_base_wl       = x(:,22);
p70_S6K_pT229_pT389_base_wl = x(:,23);
% supplemental
AMPK_pT172_base_wl    = x(:,8);  
PPRAS40_pT246_base_wl = x(:,25); 
p70_S6K_base_wl       = x(:,20);

% Base case w/o PRAS-mTORC1 link
% set parameters
akt_scaling = 1;
mtorc1_scaling = 1;
mtorc2_scaling = 1;
pi3K_pdk_scaling = 1;
b_pras_mtorc1 = 0;
base_fig_num = 0;
% execute the script
legends
% save variables
t_base_wol = t;
IRS_p_base_wol  = x(:,5);
Akt_pT308_base_wol  = x(:,10);
Akt_pS473_base_wol  = x(:,11);
Akt_pT308_pS473_base_wol = x(:,12);
mTORC1_pS2448_base_wol   = x(:,17);
mTORC2_pS2481_base_wol   = x(:,19);
PRAS40_base_wol          = x(:,24);
PI3K_p_PDK1_base_wol     = x(:,31);
p70_S6K_pT389_base_wol       = x(:,22);
p70_S6K_pT229_pT389_base_wol = x(:,23);
% supplemental
AMPK_pT172_base_wol    = x(:,8);  
PPRAS40_pT246_base_wol = x(:,25); 
p70_S6K_base_wol       = x(:,20);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Acute Rapamycin with PRAS-mTORC1 link
% set parameters
akt_scaling = 1;
mtorc1_scaling = 0.25;
mtorc2_scaling = 1;
pi3K_pdk_scaling = 1;
b_pras_mtorc1 = 1;
base_fig_num = 0;
% execute the script
legends
% save variables
t_acuteRapa_wl = t;
IRS_p_acuteRapa_wl  = x(:,5);
Akt_pT308_acuteRapa_wl  = x(:,10);
Akt_pS473_acuteRapa_wl  = x(:,11);
Akt_pT308_pS473_acuteRapa_wl = x(:,12);
mTORC1_pS2448_acuteRapa_wl   = x(:,17);
mTORC2_pS2481_acuteRapa_wl   = x(:,19);
PRAS40_acuteRapa_wl          = x(:,24);
PI3K_p_PDK1_acuteRapa_wl     = x(:,31);
p70_S6K_pT389_acuteRapa_wl       = x(:,22);
p70_S6K_pT229_pT389_acuteRapa_wl = x(:,23);
% supplemental
AMPK_pT172_acuteRapa_wl    = x(:,8);
PPRAS40_pT246_acuteRapa_wl = x(:,25); 
p70_S6K_acuteRapa_wl       = x(:,20);

% Acute Rapamycin w/o PRAS-mTORC1 link
% set parameters
akt_scaling = 1;
mtorc1_scaling = 0.25;
mtorc2_scaling = 1;
pi3K_pdk_scaling = 1;
b_pras_mtorc1 = 0;
base_fig_num = 0;
% execute the script
legends
% save variables
t_acuteRapa_wol = t;
IRS_p_acuteRapa_wol  = x(:,5);
Akt_pT308_acuteRapa_wol  = x(:,10);
Akt_pS473_acuteRapa_wol  = x(:,11);
Akt_pT308_pS473_acuteRapa_wol = x(:,12);
mTORC1_pS2448_acuteRapa_wol   = x(:,17);
mTORC2_pS2481_acuteRapa_wol   = x(:,19);
PRAS40_acuteRapa_wol          = x(:,24);
PI3K_p_PDK1_acuteRapa_wol     = x(:,31);
p70_S6K_pT389_acuteRapa_wol       = x(:,22);
p70_S6K_pT229_pT389_acuteRapa_wol = x(:,23);
% supplemental
AMPK_pT172_acuteRapa_wol    = x(:,8);
PPRAS40_pT246_acuteRapa_wol = x(:,25); 
p70_S6K_acuteRapa_wol       = x(:,20);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Chronic Rapamycin with PRAS-mTORC1 link
% set parameters
akt_scaling = 1;
mtorc1_scaling = 0.25;
mtorc2_scaling = 0.25;
pi3K_pdk_scaling = 1;
b_pras_mtorc1 = 1;
base_fig_num = 0;
% execute the script
legends
% save variables
t_chronicRapa_wl = t;
IRS_p_chronicRapa_wl  = x(:,5);
Akt_pT308_chronicRapa_wl  = x(:,10);
Akt_pS473_chronicRapa_wl  = x(:,11);
Akt_pT308_pS473_chronicRapa_wl = x(:,12);
mTORC1_pS2448_chronicRapa_wl   = x(:,17);
mTORC2_pS2481_chronicRapa_wl   = x(:,19);
PRAS40_chronicRapa_wl          = x(:,24);
PI3K_p_PDK1_chronicRapa_wl     = x(:,31);
p70_S6K_pT389_chronicRapa_wl       = x(:,22);
p70_S6K_pT229_pT389_chronicRapa_wl = x(:,23);
% supplemental
AMPK_pT172_chronicRapa_wl    = x(:,8);
PPRAS40_pT246_chronicRapa_wl = x(:,25); 
p70_S6K_chronicRapa_wl       = x(:,20);

% Chronic Rapamycin w/o PRAS-mTORC1 link
% set parameters
akt_scaling = 1;
mtorc1_scaling = 0.25;
mtorc2_scaling = 0.25;
pi3K_pdk_scaling = 1;
b_pras_mtorc1 = 0;
base_fig_num = 0;
% execute the script
legends
% save variables
t_chronicRapa_wol = t;
IRS_p_chronicRapa_wol  = x(:,5);
Akt_pT308_chronicRapa_wol  = x(:,10);
Akt_pS473_chronicRapa_wol  = x(:,11);
Akt_pT308_pS473_chronicRapa_wol = x(:,12);
mTORC1_pS2448_chronicRapa_wol   = x(:,17);
mTORC2_pS2481_chronicRapa_wol   = x(:,19);
PRAS40_chronicRapa_wol          = x(:,24);
PI3K_p_PDK1_chronicRapa_wol     = x(:,31);
p70_S6K_pT389_chronicRapa_wol       = x(:,22);
p70_S6K_pT229_pT389_chronicRapa_wol = x(:,23);
% supplemental
AMPK_pT172_chronicRapa_wol    = x(:,8);
PPRAS40_pT246_chronicRapa_wol = x(:,25); 
p70_S6K_chronicRapa_wol       = x(:,20);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Chronic Rapamycin and Wortmannin with PRAS-mTORC1 link
% set parameters
akt_scaling = 1;
mtorc1_scaling = 0.25;
mtorc2_scaling = 0.25;
pi3K_pdk_scaling = 0.2;
b_pras_mtorc1 = 1;
base_fig_num = 0;
% execute the script
legends
% save variables
t_chronicRapaWort_wl = t;
IRS_p_chronicRapaWort_wl  = x(:,5);
Akt_pT308_chronicRapaWort_wl  = x(:,10);
Akt_pS473_chronicRapaWort_wl  = x(:,11);
Akt_pT308_pS473_chronicRapaWort_wl = x(:,12);
mTORC1_pS2448_chronicRapaWort_wl   = x(:,17);
mTORC2_pS2481_chronicRapaWort_wl   = x(:,19);
PRAS40_chronicRapaWort_wl          = x(:,24);
PI3K_p_PDK1_chronicRapaWort_wl     = x(:,31);
p70_S6K_pT389_chronicRapaWort_wl       = x(:,22);
p70_S6K_pT229_pT389_chronicRapaWort_wl = x(:,23);
% supplemental
AMPK_pT172_chronicRapaWort_wl    = x(:,8);
PPRAS40_pT246_chronicRapaWort_wl = x(:,25); 
p70_S6K_chronicRapaWort_wl       = x(:,20);

% Chronic Rapamycin and Wortmannin w/o PRAS-mTORC1 link
% set parameters
akt_scaling = 1;
mtorc1_scaling = 0.25;
mtorc2_scaling = 0.25;
pi3K_pdk_scaling = 0.2;
b_pras_mtorc1 = 0;
base_fig_num = 0;
% execute the script
legends
% save variables
t_chronicRapaWort_wol = t;
IRS_p_chronicRapaWort_wol  = x(:,5);
Akt_pT308_chronicRapaWort_wol  = x(:,10);
Akt_pS473_chronicRapaWort_wol  = x(:,11);
Akt_pT308_pS473_chronicRapaWort_wol = x(:,12);
mTORC1_pS2448_chronicRapaWort_wol   = x(:,17);
mTORC2_pS2481_chronicRapaWort_wol   = x(:,19);
PRAS40_chronicRapaWort_wol          = x(:,24);
PI3K_p_PDK1_chronicRapaWort_wol     = x(:,31);
p70_S6K_pT389_chronicRapaWort_wol       = x(:,22);
p70_S6K_pT229_pT389_chronicRapaWort_wol = x(:,23);
% supplemental
AMPK_pT172_chronicRapaWort_wol    = x(:,8);
PPRAS40_pT246_chronicRapaWort_wol = x(:,25); 
p70_S6K_chronicRapaWort_wol       = x(:,20);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
t0 = 200;
figure(1), clf

subplot(3,2,1) 
ind = find(t_base_wl>t0); plot(t_base_wl(ind)-t0,mTORC1_pS2448_base_wl(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wl>t0); plot(t_acuteRapa_wl(ind)-t0,mTORC1_pS2448_acuteRapa_wl(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wl>t0); plot(t_chronicRapa_wl(ind)-t0,mTORC1_pS2448_chronicRapa_wl(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wl>t0); plot(t_chronicRapaWort_wl(ind)-t0,mTORC1_pS2448_chronicRapaWort_wl(ind),'-g','Linewidth',2);
ylim([0 5])
set(gca,'Fontsize',14)
ylabel('mTORC1\_pS2448 w/ link','Fontsize',16)
text(-10,5.6,'a','FontWeight','Bold','Fontsize',18)
subplot(3,2,2) 
ind = find(t_base_wol>t0); plot(t_base_wol(ind)-t0,mTORC1_pS2448_base_wol(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wol>t0); plot(t_acuteRapa_wol(ind)-t0,mTORC1_pS2448_acuteRapa_wol(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wol>t0); plot(t_chronicRapa_wol(ind)-t0,mTORC1_pS2448_chronicRapa_wol(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wol>t0); plot(t_chronicRapaWort_wol(ind)-t0,mTORC1_pS2448_chronicRapaWort_wol(ind),'-g','Linewidth',2);
ylim([0 5])
set(gca,'Fontsize',14)
ylabel('mTORC1\_pS2448 w/o link','Fontsize',16)
legend('Control','Acute Rapa','Chron Rapa','Chron Rapa+Wort','Fontsize',14,'Location','best')

subplot(3,2,3) 
ind = find(t_base_wl>t0); plot(t_base_wl(ind)-t0,p70_S6K_pT389_base_wl(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wl>t0); plot(t_acuteRapa_wl(ind)-t0,p70_S6K_pT389_acuteRapa_wl(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wl>t0); plot(t_chronicRapa_wl(ind)-t0,p70_S6K_pT389_chronicRapa_wl(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wl>t0); plot(t_chronicRapaWort_wl(ind)-t0,p70_S6K_pT389_chronicRapaWort_wl(ind),'-g','Linewidth',2);
ylim([0 7])
set(gca,'Fontsize',14)
ylabel('p70S6K\_pT389 w/ link','Fontsize',16)
text(-10,7.7,'b','FontWeight','Bold','Fontsize',18)
subplot(3,2,4) 
ind = find(t_base_wol>t0); plot(t_base_wol(ind)-t0,p70_S6K_pT389_base_wol(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wol>t0); plot(t_acuteRapa_wol(ind)-t0,p70_S6K_pT389_acuteRapa_wol(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wol>t0); plot(t_chronicRapa_wol(ind)-t0,p70_S6K_pT389_chronicRapa_wol(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wol>t0); plot(t_chronicRapaWort_wol(ind)-t0,p70_S6K_pT389_chronicRapaWort_wol(ind),'-g','Linewidth',2);
ylim([0 7])
set(gca,'Fontsize',14)
ylabel('p70S6K\_pT389 w/o link','Fontsize',16)

subplot(3,2,5) 
ind = find(t_base_wl>t0); plot(t_base_wl(ind)-t0,PRAS40_base_wl(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wl>t0); plot(t_acuteRapa_wl(ind)-t0,PRAS40_acuteRapa_wl(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wl>t0); plot(t_chronicRapa_wl(ind)-t0,PRAS40_chronicRapa_wl(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wl>t0); plot(t_chronicRapaWort_wl(ind)-t0,PRAS40_chronicRapaWort_wl(ind),'-g','Linewidth',2);
ylim([6 16])
set(gca,'Fontsize',14)
ylabel('PRAS40 w/ link','Fontsize',16)
text(-10,17,'c','FontWeight','Bold','Fontsize',18)
xlabel('Time (min)','Fontsize',16)
subplot(3,2,6) 
ind = find(t_base_wol>t0); plot(t_base_wol(ind)-t0,PRAS40_base_wol(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wol>t0); plot(t_acuteRapa_wol(ind)-t0,PRAS40_acuteRapa_wol(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wol>t0); plot(t_chronicRapa_wol(ind)-t0,PRAS40_chronicRapa_wol(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wol>t0); plot(t_chronicRapaWort_wol(ind)-t0,PRAS40_chronicRapaWort_wol(ind),'-g','Linewidth',2);
ylim([6 16])
set(gca,'Fontsize',14)
ylabel('PRAS40 w/o link','Fontsize',16)
xlabel('Time (min)','Fontsize',16)

%%%%%%%%%%
figure(2), clf

subplot(3,2,1) 
ind = find(t_base_wl>t0); plot(t_base_wl(ind)-t0,Akt_pS473_base_wl(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wl>t0); plot(t_acuteRapa_wl(ind)-t0,Akt_pS473_acuteRapa_wl(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wl>t0); plot(t_chronicRapa_wl(ind)-t0,Akt_pS473_chronicRapa_wl(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wl>t0); plot(t_chronicRapaWort_wl(ind)-t0,Akt_pS473_chronicRapaWort_wl(ind),'-g','Linewidth',2);
ylim([0 80])
set(gca,'Fontsize',14)
ylabel('AKT\_pS473 w/ link','Fontsize',16)
text(-10,88,'a','FontWeight','Bold','Fontsize',18)
subplot(3,2,2) 
ind = find(t_base_wol>t0); plot(t_base_wol(ind)-t0,Akt_pS473_base_wol(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wol>t0); plot(t_acuteRapa_wol(ind)-t0,Akt_pS473_acuteRapa_wol(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wol>t0); plot(t_chronicRapa_wol(ind)-t0,Akt_pS473_chronicRapa_wol(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wol>t0); plot(t_chronicRapaWort_wol(ind)-t0,Akt_pS473_chronicRapaWort_wol(ind),'-g','Linewidth',2);
ylim([0 80])
set(gca,'Fontsize',14)
ylabel('AKT\_pS473 w/o link','Fontsize',16)
legend('Control','Acute Rapa','Chron Rapa','Chron Rapa+Wort','Fontsize',14,'Location','northeast')

subplot(3,2,3) 
ind = find(t_base_wl>t0); plot(t_base_wl(ind)-t0,Akt_pT308_pS473_base_wl(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wl>t0); plot(t_acuteRapa_wl(ind)-t0,Akt_pT308_pS473_acuteRapa_wl(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wl>t0); plot(t_chronicRapa_wl(ind)-t0,Akt_pT308_pS473_chronicRapa_wl(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wl>t0); plot(t_chronicRapaWort_wl(ind)-t0,Akt_pT308_pS473_chronicRapaWort_wl(ind),'-g','Linewidth',2);
ylim([0 16])
set(gca,'Fontsize',14)
ylabel('AKT\_pT308\_pS473 w/ link','Fontsize',16)
text(-10,17.5,'b','FontWeight','Bold','Fontsize',18)
subplot(3,2,4) 
ind = find(t_base_wol>t0); plot(t_base_wol(ind)-t0,Akt_pT308_pS473_base_wol(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wol>t0); plot(t_acuteRapa_wol(ind)-t0,Akt_pT308_pS473_acuteRapa_wol(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wol>t0); plot(t_chronicRapa_wol(ind)-t0,Akt_pT308_pS473_chronicRapa_wol(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wol>t0); plot(t_chronicRapaWort_wol(ind)-t0,Akt_pT308_pS473_chronicRapaWort_wol(ind),'-g','Linewidth',2);
ylim([0 16])
set(gca,'Fontsize',14)
ylabel('AKT\_pT308\_pS473 w/o link','Fontsize',16)

subplot(3,2,5) 
ind = find(t_base_wl>t0); plot(t_base_wl(ind)-t0,IRS_p_base_wl(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wl>t0); plot(t_acuteRapa_wl(ind)-t0,IRS_p_acuteRapa_wl(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wl>t0); plot(t_chronicRapa_wl(ind)-t0,IRS_p_chronicRapa_wl(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wl>t0); plot(t_chronicRapaWort_wl(ind)-t0,IRS_p_chronicRapaWort_wl(ind),'-g','Linewidth',2);
ylim([0 120])
set(gca,'Fontsize',14)
ylabel('IRS\_p w/ link','Fontsize',16)
xlabel('Time (min)','Fontsize',16)
text(-10,135,'c','FontWeight','Bold','Fontsize',18)
subplot(3,2,6) 
ind = find(t_base_wol>t0); plot(t_base_wol(ind)-t0,IRS_p_base_wol(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wol>t0); plot(t_acuteRapa_wol(ind)-t0,IRS_p_acuteRapa_wol(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wol>t0); plot(t_chronicRapa_wol(ind)-t0,IRS_p_chronicRapa_wol(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wol>t0); plot(t_chronicRapaWort_wol(ind)-t0,IRS_p_chronicRapaWort_wol(ind),'-g','Linewidth',2);
ylim([0 120])
set(gca,'Fontsize',14)
ylabel('IRS\_p w/o link','Fontsize',16)
xlabel('Time (min)','Fontsize',16)

%%%% supplement
figure(3), clf

subplot(5,2,1) 
ind = find(t_base_wl>t0); plot(t_base_wl(ind)-t0,PPRAS40_pT246_base_wl(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wl>t0); plot(t_acuteRapa_wl(ind)-t0,PPRAS40_pT246_acuteRapa_wl(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wl>t0); plot(t_chronicRapa_wl(ind)-t0,PPRAS40_pT246_chronicRapa_wl(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wl>t0); plot(t_chronicRapaWort_wl(ind)-t0,PPRAS40_pT246_chronicRapaWort_wl(ind),'-g','Linewidth',2);
% ylim([0 60])
set(gca,'Fontsize',14)
title('PRAS40\_pT246 w/ link','Fontsize',16)
subplot(5,2,2) 
ind = find(t_base_wol>t0); plot(t_base_wol(ind)-t0,PPRAS40_pT246_base_wol(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wol>t0); plot(t_acuteRapa_wol(ind)-t0,PPRAS40_pT246_acuteRapa_wol(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wol>t0); plot(t_chronicRapa_wol(ind)-t0,PPRAS40_pT246_chronicRapa_wol(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wol>t0); plot(t_chronicRapaWort_wol(ind)-t0,PPRAS40_pT246_chronicRapaWort_wol(ind),'-g','Linewidth',2);
% ylim([0 60])
set(gca,'Fontsize',14)
title('PRAS40\_pT246 w/o link','Fontsize',16)

subplot(5,2,3) 
ind = find(t_base_wl>t0); plot(t_base_wl(ind)-t0,AMPK_pT172_base_wl(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wl>t0); plot(t_acuteRapa_wl(ind)-t0,AMPK_pT172_acuteRapa_wl(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wl>t0); plot(t_chronicRapa_wl(ind)-t0,AMPK_pT172_chronicRapa_wl(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wl>t0); plot(t_chronicRapaWort_wl(ind)-t0,AMPK_pT172_chronicRapaWort_wl(ind),'-g','Linewidth',2);
ylim([27 31])
set(gca,'Fontsize',14)
title('AMPK\_pT172 w/ link','Fontsize',16)
subplot(5,2,4) 
ind = find(t_base_wol>t0); plot(t_base_wol(ind)-t0,AMPK_pT172_base_wol(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wol>t0); plot(t_acuteRapa_wol(ind)-t0,AMPK_pT172_acuteRapa_wol(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wol>t0); plot(t_chronicRapa_wol(ind)-t0,AMPK_pT172_chronicRapa_wol(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wol>t0); plot(t_chronicRapaWort_wol(ind)-t0,AMPK_pT172_chronicRapaWort_wol(ind),'-g','Linewidth',2);
ylim([27 31])
set(gca,'Fontsize',14)
title('AMPK\_pT172 w/o link','Fontsize',16)

subplot(5,2,5) 
ind = find(t_base_wl>t0); plot(t_base_wl(ind)-t0,mTORC2_pS2481_base_wl(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wl>t0); plot(t_acuteRapa_wl(ind)-t0,mTORC2_pS2481_acuteRapa_wl(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wl>t0); plot(t_chronicRapa_wl(ind)-t0,mTORC2_pS2481_chronicRapa_wl(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wl>t0); plot(t_chronicRapaWort_wl(ind)-t0,mTORC2_pS2481_chronicRapaWort_wl(ind),'-g','Linewidth',2);
ylim([0 6])
set(gca,'Fontsize',14)
title('mTORC2\_pS2481 w/ link','Fontsize',16)
subplot(5,2,6) 
ind = find(t_base_wol>t0); plot(t_base_wol(ind)-t0,mTORC2_pS2481_base_wol(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wol>t0); plot(t_acuteRapa_wol(ind)-t0,mTORC2_pS2481_acuteRapa_wol(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wol>t0); plot(t_chronicRapa_wol(ind)-t0,mTORC2_pS2481_chronicRapa_wol(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wol>t0); plot(t_chronicRapaWort_wol(ind)-t0,mTORC2_pS2481_chronicRapaWort_wol(ind),'-g','Linewidth',2);
ylim([0 6])
set(gca,'Fontsize',14)
title('mTORC2\_pS2481 w/o link','Fontsize',16)
legend('Control','Acute Rapa','Chron Rapa','Chron Rapa+Wort','Fontsize',14,'Location','northeast')

subplot(5,2,7) 
ind = find(t_base_wl>t0); plot(t_base_wl(ind)-t0,p70_S6K_pT229_pT389_base_wl(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wl>t0); plot(t_acuteRapa_wl(ind)-t0,p70_S6K_pT229_pT389_acuteRapa_wl(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wl>t0); plot(t_chronicRapa_wl(ind)-t0,p70_S6K_pT229_pT389_chronicRapa_wl(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wl>t0); plot(t_chronicRapaWort_wl(ind)-t0,p70_S6K_pT229_pT389_chronicRapaWort_wl(ind),'-g','Linewidth',2);
ylim([0 32])
set(gca,'Fontsize',14)
title('p70S6K\_pT229 pT389 w/ link','Fontsize',16)
subplot(5,2,8) 
ind = find(t_base_wol>t0); plot(t_base_wol(ind)-t0,p70_S6K_pT229_pT389_base_wol(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wol>t0); plot(t_acuteRapa_wol(ind)-t0,p70_S6K_pT229_pT389_acuteRapa_wol(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wol>t0); plot(t_chronicRapa_wol(ind)-t0,p70_S6K_pT229_pT389_chronicRapa_wol(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wol>t0); plot(t_chronicRapaWort_wol(ind)-t0,p70_S6K_pT229_pT389_chronicRapaWort_wol(ind),'-g','Linewidth',2);
ylim([0 32])
set(gca,'Fontsize',14)
title('p70S6K\_pT229 pT389 w/o link','Fontsize',16)

subplot(5,2,9) 
ind = find(t_base_wl>t0); plot(t_base_wl(ind)-t0,PI3K_p_PDK1_base_wl(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wl>t0); plot(t_acuteRapa_wl(ind)-t0,PI3K_p_PDK1_acuteRapa_wl(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wl>t0); plot(t_chronicRapa_wl(ind)-t0,PI3K_p_PDK1_chronicRapa_wl(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wl>t0); plot(t_chronicRapaWort_wl(ind)-t0,PI3K_p_PDK1_chronicRapaWort_wl(ind),'-g','Linewidth',2);
ylim([0 3])
set(gca,'Fontsize',14)
title('PI3K\_p\_PDK1 w/ link','Fontsize',16)
xlabel('Time (min)','Fontsize',16)
subplot(5,2,10) 
ind = find(t_base_wol>t0); plot(t_base_wol(ind)-t0,PI3K_p_PDK1_base_wol(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wol>t0); plot(t_acuteRapa_wol(ind)-t0,PI3K_p_PDK1_acuteRapa_wol(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa_wol>t0); plot(t_chronicRapa_wol(ind)-t0,PI3K_p_PDK1_chronicRapa_wol(ind),'--b','Linewidth',2);
ind = find(t_chronicRapaWort_wol>t0); plot(t_chronicRapaWort_wol(ind)-t0,PI3K_p_PDK1_chronicRapaWort_wol(ind),'-g','Linewidth',2);
ylim([0 3])
set(gca,'Fontsize',14)
title('PI3K\_p\_PDK1 w/o link','Fontsize',16)
xlabel('Time (min)','Fontsize',16)
