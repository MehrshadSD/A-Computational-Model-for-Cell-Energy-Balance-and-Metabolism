clear all

glucose_tolerance = 1;  % doing glucose tolerance test

% Base case with PRAS-mTORC1 link
% set parameters
akt_scaling = 1;
mtorc1_scaling = 1;
mtorc2_scaling = 1;
pi3K_pdk_scaling = 1;
b_pras_mtorc1 = 1;
base_fig_num = 2;
% execute the script
legends
% save variables
t_base_wl = t;
IRS_p_base_wl           = x(:,5);
Akt_pT308_pS473_base_wl = x(:,12);
glucose_base_wl         = x(:,68);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Acute Rapamycin with PRAS-mTORC1 link
% set parameters
akt_scaling = 1;
mtorc1_scaling = 0.25;
mtorc2_scaling = 1;
pi3K_pdk_scaling = 1;
b_pras_mtorc1 = 1;
base_fig_num = 0;
% execute the script
legends
% save variables
t_acuteRapa_wl = t;
IRS_p_acuteRapa_wl           = x(:,5);
Akt_pT308_pS473_acuteRapa_wl = x(:,12);
glucose_acuteRapa_wl         = x(:,68);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Chronic Rapamycin with PRAS-mTORC1 link
% 75% inhibition
% set parameters
akt_scaling = 1;
mtorc1_scaling = 0.25;
mtorc2_scaling = 0.25;
pi3K_pdk_scaling = 1;
b_pras_mtorc1 = 1;
base_fig_num = 0;
% execute the script
legends
% save variables
t_chronicRapa75_wl = t;
IRS_p_chronicRapa75_wl           = x(:,5);
Akt_pT308_pS473_chronicRapa75_wl = x(:,12);
glucose_chronicRapa75_wl         = x(:,68);

% Chronic Rapamycin with PRAS-mTORC1 link
% 65% inhibition
% set parameters
akt_scaling = 1;
mtorc1_scaling = 0.25;
mtorc2_scaling = 0.35;
pi3K_pdk_scaling = 1;
b_pras_mtorc1 = 1;
base_fig_num = 0;
% execute the script
legends
% save variables
t_chronicRapa65_wl = t;
IRS_p_chronicRapa65_wl           = x(:,5);
Akt_pT308_pS473_chronicRapa65_wl = x(:,12);
glucose_chronicRapa65_wl         = x(:,68);

% 50% inhibition
% set parameters
akt_scaling = 1;
mtorc1_scaling = 0.25;
mtorc2_scaling = 0.5;
pi3K_pdk_scaling = 1;
b_pras_mtorc1 = 1;
base_fig_num = 0;
% execute the script
legends
% save variables
t_chronicRapa50_wl = t;
IRS_p_chronicRapa50_wl           = x(:,5);
Akt_pT308_pS473_chronicRapa50_wl = x(:,12);
glucose_chronicRapa50_wl         = x(:,68);

% 25% inhibition
% set parameters
akt_scaling = 1;
mtorc1_scaling = 0.25;
mtorc2_scaling = 0.75;
pi3K_pdk_scaling = 1;
b_pras_mtorc1 = 1;
base_fig_num = 0;
% execute the script
legends
% save variables
t_chronicRapa25_wl = t;
IRS_p_chronicRapa25_wl           = x(:,5);
Akt_pT308_pS473_chronicRapa25_wl = x(:,12);
glucose_chronicRapa25_wl         = x(:,68);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Chronic Rapamycin and Wortmannin with PRAS-mTORC1 link
% set parameters
akt_scaling = 1;
mtorc1_scaling = 0.25;
mtorc2_scaling = 0.25;
pi3K_pdk_scaling = 0.2;
b_pras_mtorc1 = 1;
base_fig_num = 0;
% execute the script
legends
% save variables
t_chronicRapaWort_wl = t;
IRS_p_chronicRapaWort_wl           = x(:,5);
Akt_pT308_pS473_chronicRapaWort_wl = x(:,12);
glucose_chronicRapaWort_wl         = x(:,68);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
t0 = 200;
figure(2), clf

ind = find(t_base_wl>t0); plot(t_base_wl(ind)-t0,glucose_base_wl(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wl>t0); plot(t_acuteRapa_wl(ind)-t0,glucose_acuteRapa_wl(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa75_wl>t0); plot(t_chronicRapa75_wl(ind)-t0,glucose_chronicRapa75_wl(ind),'-b','Linewidth',2);
ind = find(t_chronicRapa50_wl>t0); plot(t_chronicRapa65_wl(ind)-t0,glucose_chronicRapa65_wl(ind),'--b','Linewidth',2);
ind = find(t_chronicRapa50_wl>t0); plot(t_chronicRapa50_wl(ind)-t0,glucose_chronicRapa50_wl(ind),'-.b','Linewidth',2);
ind = find(t_chronicRapa25_wl>t0); plot(t_chronicRapa25_wl(ind)-t0,glucose_chronicRapa25_wl(ind),':b','Linewidth',2);
ind = find(t_chronicRapaWort_wl>t0); plot(t_chronicRapaWort_wl(ind)-t0,glucose_chronicRapaWort_wl(ind),'-g','Linewidth',2);
set(gca,'Fontsize',16)
ylabel('Normalized blood glucose','Fontsize',18)
xlabel('Time (min)','Fontsize',18)

vehicle = [0.09478672985781955, 92.00000000000006
15.260663507109001, 252.00000000000003
29.952606635071085, 234.00000000000003
45.11848341232227, 194.00000000000006
59.81042654028435, 166.00000000000006
120, 92.00000000000006];

scatter(vehicle(:,1)+40,vehicle(:,2)./125,'ko','Linewidth',3);
legend('Control','Acute Rapa','Chron Rapa 75%','Chron Rapa 65%','Chron Rapa 50%','Chron Rapa 25%','Chron Rapa+Wort','Vehicle data','Fontsize',18,'Location','best')

figure(5), clf
subplot(1,2,1) 
ind = find(t_base_wl>t0); plot(t_base_wl(ind)-t0,IRS_p_base_wl(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wl>t0); plot(t_acuteRapa_wl(ind)-t0,IRS_p_acuteRapa_wl(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa75_wl>t0); plot(t_chronicRapa75_wl(ind)-t0,IRS_p_chronicRapa75_wl(ind),'-b','Linewidth',2);
ind = find(t_chronicRapaWort_wl>t0); plot(t_chronicRapaWort_wl(ind)-t0,IRS_p_chronicRapaWort_wl(ind),'-g','Linewidth',2);
set(gca,'Fontsize',16)
title('IRS','Fontsize',18)
legend('Control','Acute Rapa','Chron Rapa','Chron Rapa+Wort','Fontsize',14,'Location','northeast')
xlabel('Time (min)','Fontsize',18)
subplot(1,2,2) 
ind = find(t_base_wl>t0); plot(t_base_wl(ind)-t0,Akt_pT308_pS473_base_wl(ind),'-k','Linewidth',2);
hold on
ind = find(t_acuteRapa_wl>t0); plot(t_acuteRapa_wl(ind)-t0,Akt_pT308_pS473_acuteRapa_wl(ind),'-r','Linewidth',2);
ind = find(t_chronicRapa75_wl>t0); plot(t_chronicRapa75_wl(ind)-t0,Akt_pT308_pS473_chronicRapa75_wl(ind),'-b','Linewidth',2);
ind = find(t_chronicRapaWort_wl>t0); plot(t_chronicRapaWort_wl(ind)-t0,Akt_pT308_pS473_chronicRapaWort_wl(ind),'-g','Linewidth',2);
set(gca,'Fontsize',16)
title('Akt pT308 pS473','Fontsize',18)
xlabel('Time (min)','Fontsize',18)
