clear all

leucine_conc = 0.1;
sestrine_conc= 0.1;
exp_num = 2;
arginine = 1;

sirtKm_scaling = 1;
legends_STAC
sirt_km1        = x(:,56);
nad_km1         = x(:,54);
nam_km1         = x(:,53);
nmn_km1         = x(:,50);
nampt_km1       = x(:,60);
AMPK_pT172_km1  = x(:,8);
mTORC1_pS2448_km1 = x(:,17);
ULK1s_km1       = x(:,61);
t_km1           = t;

sirtKm_scaling = 0.8;
legends_STAC
sirt_km_a        = x(:,56);
nad_km_a         = x(:,54);
nam_km_a         = x(:,53);
nmn_km_a         = x(:,50);
nampt_km_a       = x(:,60);
AMPK_pT172_km_a  = x(:,8);
mTORC1_pS2448_km_a = x(:,17);
ULK1s_km_a       = x(:,61);
t_km_a           = t;

sirtKm_scaling = 0.55;
legends_STAC
sirt_km_b        = x(:,56);
nad_km_b         = x(:,54);
nam_km_b         = x(:,53);
nmn_km_b         = x(:,50);
nampt_km_b       = x(:,60);
AMPK_pT172_km_b  = x(:,8);
mTORC1_pS2448_km_b = x(:,17);
ULK1s_km_b       = x(:,61);
t_km_b           = t;

sirtKm_scaling = 0.4;
legends_STAC
sirt_km_c        = x(:,56);
nad_km_c         = x(:,54);
nam_km_c         = x(:,53);
nmn_km_c         = x(:,50);
nampt_km_c       = x(:,60);
AMPK_pT172_km_c  = x(:,8);
mTORC1_pS2448_km_c = x(:,17);
ULK1s_km_c       = x(:,61);
t_km_c           = t;

sirtKm_scaling = 0.3;
legends_STAC
sirt_km_d        = x(:,56);
nad_km_d         = x(:,54);
nam_km_d         = x(:,53);
nmn_km_d         = x(:,50);
nampt_km_d       = x(:,60);
AMPK_pT172_km_d  = x(:,8);
mTORC1_pS2448_km_d = x(:,17);
ULK1s_km_d       = x(:,61);
t_km_d           = t;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(3), clf
subplot(3,1,1)
data_sirt = [sirt_km1(end) sirt_km_a(end) sirt_km_b(end) sirt_km_c(end) sirt_km_d(end)]./sirt_km1(end);
data_ampk = [AMPK_pT172_km1(end) AMPK_pT172_km_a(end) AMPK_pT172_km_b(end) AMPK_pT172_km_c(end) AMPK_pT172_km_d(end)]./AMPK_pT172_km1(end);
bar([data_sirt; data_ampk])
set(gca,'Fontsize',14)
set(gca,'XTickLabel',{'SIRT1','AMPK\_pT172'})
% legend('Vehicle','Resveratrol','SRT2183','SRT1460','SRT1720','Fontsize',14,'Location','northeast')
text(0.55,1.6,'a','FontWeight','Bold','Fontsize',18)
text(1.55,1.6,'b','FontWeight','Bold','Fontsize',18)

subplot(3,1,2)
data_nampt = [nampt_km1(end) nampt_km_a(end) nampt_km_b(end) nampt_km_c(end) nampt_km_d(end)]./nampt_km1(end);
data_nad  = [nad_km1(end) nad_km_a(end) nad_km_b(end) nad_km_c(end) nad_km_d(end)]./nad_km1(end);
bar([data_nampt; data_nad])
set(gca,'Fontsize',14)
set(gca,'XTickLabel',{'NAMPT','NAD+'})
legend('Vehicle','Resveratrol','SRT2183','SRT1460','SRT1720','Fontsize',14,'Location','northeast')
text(0.55,1.3,'c','FontWeight','Bold','Fontsize',18)
text(1.55,1.3,'d','FontWeight','Bold','Fontsize',18)
ylim([0 1.2])

subplot(3,1,3)
data_mtorc = [mTORC1_pS2448_km1(end) mTORC1_pS2448_km_a(end) mTORC1_pS2448_km_b(end) mTORC1_pS2448_km_c(end) mTORC1_pS2448_km_d(end)]./mTORC1_pS2448_km1(end);
data_ulk = [ULK1s_km1(end) ULK1s_km_a(end) ULK1s_km_b(end) ULK1s_km_c(end) ULK1s_km_d(end)]./ULK1s_km1(end);
bar([data_mtorc; data_ulk])
set(gca,'Fontsize',14)
set(gca,'XTickLabel',{'mTORC1\_pS2448','Act ULK1'})
% legend('Vehicle','Resveratrol','SRT2183','SRT1460','SRT1720','Fontsize',14,'Location','northeast')
text(0.55,1.6,'e','FontWeight','Bold','Fontsize',18)
text(1.55,1.6,'f','FontWeight','Bold','Fontsize',18)

t0 = 0; tf = 480;
figure(1), clf

subplot(3,2,1) 
ind = find(t_km1<tf & t_km1>t0); plot(t_km1(ind)-t0,sirt_km1(ind),'-k','Linewidth',2);
hold on
ind = find(t_km_a<tf & t_km_a>t0); plot(t_km_a(ind)-t0,sirt_km_a(ind),'-b','Linewidth',2);
ind = find(t_km_b<tf & t_km_b>t0); plot(t_km_b(ind)-t0,sirt_km_b(ind),'-r','Linewidth',2);
ind = find(t_km_c<tf & t_km_c>t0); plot(t_km_c(ind)-t0,sirt_km_c(ind),'-g','Linewidth',2);
ind = find(t_km_d<tf & t_km_d>t0); plot(t_km_d(ind)-t0,sirt_km_d(ind),'-m','Linewidth',2);
set(gca,'Fontsize',14)
title('A:  SIRT','Fontsize',16)

subplot(3,2,2) 
ind = find(t_km1<tf & t_km1>t0); plot(t_km1(ind)-t0,nad_km1(ind),'-k','Linewidth',2);
hold on
ind = find(t_km_a<tf & t_km_a>t0); plot(t_km_a(ind)-t0,nad_km_a(ind),'-b','Linewidth',2);
ind = find(t_km_b<tf & t_km_b>t0); plot(t_km_b(ind)-t0,nad_km_b(ind),'-r','Linewidth',2);
ind = find(t_km_c<tf & t_km_c>t0); plot(t_km_c(ind)-t0,nad_km_c(ind),'-g','Linewidth',2);
ind = find(t_km_d<tf & t_km_d>t0); plot(t_km_d(ind)-t0,nad_km_d(ind),'-m','Linewidth',2);
set(gca,'Fontsize',14)
title('B:  NAD','Fontsize',16)

subplot(3,2,3) 
ind = find(t_km1<tf & t_km1>t0); plot(t_km1(ind)-t0,AMPK_pT172_km1(ind),'-k','Linewidth',2);
hold on
ind = find(t_km_a<tf & t_km_a>t0); plot(t_km_a(ind)-t0,AMPK_pT172_km_a(ind),'-b','Linewidth',2);
ind = find(t_km_b<tf & t_km_b>t0); plot(t_km_b(ind)-t0,AMPK_pT172_km_b(ind),'-r','Linewidth',2);
ind = find(t_km_c<tf & t_km_c>t0); plot(t_km_c(ind)-t0,AMPK_pT172_km_c(ind),'-g','Linewidth',2);
ind = find(t_km_d<tf & t_km_d>t0); plot(t_km_d(ind)-t0,AMPK_pT172_km_d(ind),'-m','Linewidth',2);
set(gca,'Fontsize',14)
title('C:  AMPK pT172','Fontsize',16)

subplot(3,2,4)
ind = find(t_km1<tf & t_km1>t0); plot(t_km1(ind)-t0,ULK1s_km1(ind),'-k','Linewidth',2);
hold on
ind = find(t_km_a<tf & t_km_a>t0); plot(t_km_a(ind)-t0,ULK1s_km_a(ind),'-b','Linewidth',2);
ind = find(t_km_b<tf & t_km_b>t0); plot(t_km_b(ind)-t0,ULK1s_km_b(ind),'-r','Linewidth',2);
ind = find(t_km_c<tf & t_km_c>t0); plot(t_km_c(ind)-t0,ULK1s_km_c(ind),'-g','Linewidth',2);
ind = find(t_km_d<tf & t_km_d>t0); plot(t_km_d(ind)-t0,ULK1s_km_d(ind),'-m','Linewidth',2);
set(gca,'Fontsize',14)
title('D:  ULK1s','Fontsize',16)

% subplot(3,2,5)
% ind = find(t_km1<tf & t_km1>t0); plot(t_km1(ind)-t0,nam_km1(ind),'-k','Linewidth',2);
% hold on
% ind = find(t_km_a<tf & t_km_a>t0); plot(t_km_a(ind)-t0,nam_km_a(ind),'-b','Linewidth',2);
% ind = find(t_km_b<tf & t_km_b>t0); plot(t_km_b(ind)-t0,nam_km_b(ind),'-r','Linewidth',2);
% ind = find(t_km_c<tf & t_km_c>t0); plot(t_km_c(ind)-t0,nam_km_c(ind),'-g','Linewidth',2);
% ind = find(t_km_d<tf & t_km_d>t0); plot(t_km_d(ind)-t0,nam_km_d(ind),'-m','Linewidth',2);
% set(gca,'Fontsize',14)
% title('E:  NAM','Fontsize',16)
% legend('Vehicle','Resveratrol','SRT2183','SRT1460','SRT1720','Fontsize',14,'Location','southeast')

subplot(3,2,5)
ind = find(t_km1<tf & t_km1>t0); plot(t_km1(ind)-t0,mTORC1_pS2448_km1(ind),'-k','Linewidth',2);
hold
ind = find(t_km_a<tf & t_km_a>t0); plot(t_km_a(ind)-t0,mTORC1_pS2448_km_a(ind),'-b','Linewidth',2);
ind = find(t_km_b<tf & t_km_b>t0); plot(t_km_b(ind)-t0,mTORC1_pS2448_km_b(ind),'-r','Linewidth',2);
ind = find(t_km_c<tf & t_km_c>t0); plot(t_km_c(ind)-t0,mTORC1_pS2448_km_c(ind),'-g','Linewidth',2);
ind = find(t_km_d<tf & t_km_d>t0); plot(t_km_d(ind)-t0,mTORC1_pS2448_km_d(ind),'-m','Linewidth',2);
set(gca,'Fontsize',14)
title('E:  mTORC1 pS2448','Fontsize',16)
legend('Vehicle','Resveratrol','SRT2183','SRT1460','SRT1720','Fontsize',14,'Location','southeast')

subplot(3,2,6)
ind = find(t_km1<tf & t_km1>t0); plot(t_km1(ind)-t0,nampt_km1(ind),'-k','Linewidth',2);
hold on
ind = find(t_km_a<tf & t_km_a>t0); plot(t_km_a(ind)-t0,nampt_km_a(ind),'-b','Linewidth',2);
ind = find(t_km_b<tf & t_km_b>t0); plot(t_km_b(ind)-t0,nampt_km_b(ind),'-r','Linewidth',2);
ind = find(t_km_c<tf & t_km_c>t0); plot(t_km_c(ind)-t0,nampt_km_c(ind),'-g','Linewidth',2);
ind = find(t_km_d<tf & t_km_d>t0); plot(t_km_d(ind)-t0,nampt_km_d(ind),'-m','Linewidth',2);
set(gca,'Fontsize',14)
title('F:  NAMPT','Fontsize',16)


figure(2), clf
subplot(3,1,2)
% ind = find(t_km1<tf & t_km1>t0); plot(t_km1(ind)-t0,x(ind,58),'-k','Linewidth',2);
foxo_c = [0:600];
xx1 = sirt_km1(end)*0.5e6*(0.077)*(foxo_c)./(141+foxo_c);
xxa = sirt_km1(end)*0.5e6*(0.077)*(foxo_c)./(141*0.8+foxo_c);
xxb = sirt_km1(end)*0.5e6*(0.077)*(foxo_c)./(141*0.55+foxo_c);
xxc = sirt_km1(end)*0.5e6*(0.077)*(foxo_c)./(141*0.4+foxo_c);
xxd = sirt_km1(end)*0.5e6*(0.077)*(foxo_c)./(141*0.3+foxo_c);
plot(foxo_c,xx1,'-k','Linewidth',2)
hold on
plot(foxo_c,xxa,'-b','Linewidth',2)
plot(foxo_c,xxb,'-r','Linewidth',2)
plot(foxo_c,xxc,'-g','Linewidth',2)
plot(foxo_c,xxd,'-m','Linewidth',2)
set(gca,'Fontsize',14)
xlabel('FOXO (\muM)','Fontsize',16)
ylabel('Deacetylation rate (\muM/s)','Fontsize',16)
legend('Vehicle','Resveratrol','SRT2183','SRT1460','SRT1720','Fontsize',14,'Location','southeast')
text(-25,0.067,'b','FontWeight','Bold','Fontsize',16)

subplot(3,1,3)
% ind = find(t_km1<tf & t_km1>t0); plot(t_km1(ind)-t0,x(ind,58),'-k','Linewidth',2);
pgc1 = [0:600];
xx1 = (0.077*(1.7e5*sirt_km1(end))*pgc1)./(121+pgc1);
xxa = (0.077*(1.7e5*sirt_km1(end))*pgc1)./(121*0.8+pgc1);
xxb = (0.077*(1.7e5*sirt_km1(end))*pgc1)./(121*0.55+pgc1);
xxc = (0.077*(1.7e5*sirt_km1(end))*pgc1)./(121*0.4+pgc1);
xxd = (0.077*(1.7e5*sirt_km1(end))*pgc1)./(121*0.3+pgc1);
plot(pgc1,xx1,'-k','Linewidth',2)
hold on
plot(pgc1,xxa,'-b','Linewidth',2)
plot(pgc1,xxb,'-r','Linewidth',2)
plot(pgc1,xxc,'-g','Linewidth',2)
plot(pgc1,xxd,'-m','Linewidth',2)
set(gca,'Fontsize',14)
xlabel('PGC-1\alpha (\muM)','Fontsize',16)
ylabel('Deacetylation rate (\muM/s)','Fontsize',16)
text(-25,0.022,'c','FontWeight','Bold','Fontsize',16)

NamPT_compartment = 0.001;
SIRT_ET = 10;
SIRT_scaling = 0.001;
SIRT_Kcat = 0.67;
NAD = [0:1e-5:12e-3];
NAD = [0:1e-3:0.3];
H3_ac = 1;
SIRT_Km = 0.029;  % SIRT_Km scaled
SIRT_Ki = 0.06;

subplot(3,1,1)
SIRT1 = NamPT_compartment * ((SIRT_ET * (SIRT_scaling * (SIRT_Kcat * NAD * H3_ac./(((SIRT_Km + NAD) * (1+x(end,53)/(SIRT_Ki))))))));
SIRTa = NamPT_compartment * ((SIRT_ET * (SIRT_scaling * (SIRT_Kcat * NAD * H3_ac./(((SIRT_Km*0.8 + NAD) * (1+x(end,53)/(SIRT_Ki))))))));
SIRTb = NamPT_compartment * ((SIRT_ET * (SIRT_scaling * (SIRT_Kcat * NAD * H3_ac./(((SIRT_Km*0.55 + NAD) * (1+x(end,53)/(SIRT_Ki))))))));
SIRTc = NamPT_compartment * ((SIRT_ET * (SIRT_scaling * (SIRT_Kcat * NAD * H3_ac./(((SIRT_Km*0.4 + NAD) * (1+x(end,53)/(SIRT_Ki))))))));
SIRTd = NamPT_compartment * ((SIRT_ET * (SIRT_scaling * (SIRT_Kcat * NAD * H3_ac./(((SIRT_Km*0.3 + NAD) * (1+x(end,53)/(SIRT_Ki))))))));
plot(NAD,SIRT1./SIRTd(end),'-k','Linewidth',2)
hold on
plot(NAD,SIRTa./SIRTd(end),'-b','Linewidth',2)
plot(NAD,SIRTb./SIRTd(end),'-r','Linewidth',2)
plot(NAD,SIRTc./SIRTd(end),'-g','Linewidth',2)
plot(NAD,SIRTd./SIRTd(end),'-m','Linewidth',2)
set(gca,'Fontsize',14)
xlabel('NAD+','Fontsize',16)
ylabel('Relative SIRT1 activity','Fontsize',16)
text(-0.013,1.1,'a','FontWeight','Bold','Fontsize',16)
