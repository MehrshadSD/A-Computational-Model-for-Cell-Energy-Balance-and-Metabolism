arginine = 1;
exp_num = 2;

leucine_conc = 0.1;
sestrine_conc= 1;
legends_AA
mTORC1_pS2448_ses0 = x(:,17);
p70_S6K_pT389_ses0 = x(:,22);
AMPK_pT172_ses0    = x(:,8);
ULK1s_ses0         = x(:,61);
t_ses0             = t;
% supplement
IRS_p_ses0         = x(:,5);
Akt_pT308_ses0     = x(:,10);
p70_S6K_pT389_ses0 = x(:,22);
PRAS40_pS183_ses0  = x(:,26);

leucine_conc = 0.1;
sestrine_conc= 0.1;
legends_AA
mTORC1_pS2448_ses1 = x(:,17);
p70_S6K_pT389_ses1 = x(:,22);
AMPK_pT172_ses1    = x(:,8);
ULK1s_ses1         = x(:,61);
t_ses1             = t;
% supplement
IRS_p_ses1         = x(:,5);
Akt_pT308_ses1     = x(:,10);
p70_S6K_pT389_ses1 = x(:,22);
PRAS40_pS183_ses1  = x(:,26);

leucine_conc = 0.1;
sestrine_conc= 0.01;
legends_AA
mTORC1_pS2448_ses2 = x(:,17);
p70_S6K_pT389_ses2 = x(:,22);
AMPK_pT172_ses2    = x(:,8);
ULK1s_ses2         = x(:,61);
t_ses2             = t;
% supplement
IRS_p_ses2         = x(:,5);
Akt_pT308_ses2     = x(:,10);
p70_S6K_pT389_ses2 = x(:,22);
PRAS40_pS183_ses2  = x(:,26);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
t0 = 120; tf = 360;
figure(1), clf

subplot(2,2,1) 
ind = find((t_ses0<tf)&(t_ses0>t0)); plot(t_ses0(ind)-t0,mTORC1_pS2448_ses0(ind),'-k','Linewidth',2);
hold on
ind = find((t_ses1<tf)&(t_ses1>t0)); plot(t_ses1(ind)-t0,mTORC1_pS2448_ses1(ind),'-r','Linewidth',2);
ind = find((t_ses2<tf)&(t_ses2>t0)); plot(t_ses2(ind)-t0,mTORC1_pS2448_ses2(ind),'-b','Linewidth',2);
set(gca,'Fontsize',14)
ylabel('mTORC1\_pS2448','Fontsize',16)
xlabel('Time (min)','Fontsize',16)

subplot(2,2,3)
ind = find((t_ses0<tf)&(t_ses0>t0)); plot(t_ses0(ind)-t0,p70_S6K_pT389_ses0(ind),'-k','Linewidth',2);
hold on
ind = find((t_ses1<tf)&(t_ses1>t0)); plot(t_ses1(ind)-t0,p70_S6K_pT389_ses1(ind),'-r','Linewidth',2);
ind = find((t_ses1<tf)&(t_ses1>t0)); plot(t_ses2(ind)-t0,p70_S6K_pT389_ses2(ind),'-b','Linewidth',2);
set(gca,'Fontsize',14)
ylabel('p70S6K\_pT389','Fontsize',16)
xlabel('Time (min)','Fontsize',16)

subplot(2,2,2)
ind = find((t_ses0<tf)&(t_ses0>t0)); plot(t_ses0(ind)-t0,ULK1s_ses0(ind),'-k','Linewidth',2);
% ylim([0 5])
hold on
ind = find((t_ses1<tf)&(t_ses1>t0)); plot(t_ses1(ind)-t0,ULK1s_ses1(ind),'-r','Linewidth',2);
ind = find((t_ses2<tf)&(t_ses2>t0)); plot(t_ses2(ind)-t0,ULK1s_ses2(ind),'-b','Linewidth',2);
set(gca,'Fontsize',14)
ylabel('Act ULK1','Fontsize',16)
xlabel('Time (min)','Fontsize',16)

subplot(2,2,4)
ind = find((t_ses0<tf)&(t_ses0>t0)); plot(t_ses0(ind)-t0,AMPK_pT172_ses0(ind),'-k','Linewidth',2);
% ylim([0 5])
hold on
ind = find((t_ses1<tf)&(t_ses1>t0)); plot(t_ses1(ind)-t0,AMPK_pT172_ses1(ind),'-r','Linewidth',2);
ind = find((t_ses2<tf)&(t_ses2>t0)); plot(t_ses2(ind)-t0,AMPK_pT172_ses2(ind),'-b','Linewidth',2);
set(gca,'Fontsize',14)
ylabel('AMPK\_pT172','Fontsize',16)
xlabel('Time (min)','Fontsize',16)
legend('High Sestrin','Medium Sestrin','Low Sestrin','Fontsize',14,'Location','northeast')

% supplement
figure(2), clf

subplot(2,2,1) 
ind = find((t_ses0<tf)&(t_ses0>t0)); plot(t_ses0(ind)-t0,IRS_p_ses0(ind),'-k','Linewidth',2);
hold on
ind = find((t_ses1<tf)&(t_ses1>t0)); plot(t_ses1(ind)-t0,IRS_p_ses1(ind),'-r','Linewidth',2);
ind = find((t_ses2<tf)&(t_ses2>t0)); plot(t_ses2(ind)-t0,IRS_p_ses2(ind),'-b','Linewidth',2);
set(gca,'Fontsize',14)
title('A:  IRS p','Fontsize',16)

subplot(2,2,2)
ind = find((t_ses0<tf)&(t_ses0>t0)); plot(t_ses0(ind)-t0,Akt_pT308_ses0(ind),'-k','Linewidth',2);
hold on
ind = find((t_ses1<tf)&(t_ses1>t0)); plot(t_ses1(ind)-t0,Akt_pT308_ses1(ind),'-r','Linewidth',2);
ind = find((t_ses1<tf)&(t_ses1>t0)); plot(t_ses2(ind)-t0,Akt_pT308_ses2(ind),'-b','Linewidth',2);
set(gca,'Fontsize',14)
title('B:  Akt pT308','Fontsize',16)

subplot(2,2,3)
ind = find((t_ses0<tf)&(t_ses0>t0)); plot(t_ses0(ind)-t0,p70_S6K_pT389_ses0(ind),'-k','Linewidth',2);
% ylim([0 5])
hold on
ind = find((t_ses1<tf)&(t_ses1>t0)); plot(t_ses1(ind)-t0,p70_S6K_pT389_ses1(ind),'-r','Linewidth',2);
ind = find((t_ses2<tf)&(t_ses2>t0)); plot(t_ses2(ind)-t0,p70_S6K_pT389_ses2(ind),'-b','Linewidth',2);
set(gca,'Fontsize',14)
title('C:  p70 S6K pT389','Fontsize',16)
xlabel('Time (min)','Fontsize',16)

subplot(2,2,4)
ind = find((t_ses0<tf)&(t_ses0>t0)); plot(t_ses0(ind)-t0,PRAS40_pS183_ses0(ind),'-k','Linewidth',2);
% ylim([0 5])
hold on
ind = find((t_ses1<tf)&(t_ses1>t0)); plot(t_ses1(ind)-t0,PRAS40_pS183_ses1(ind),'-r','Linewidth',2);
ind = find((t_ses2<tf)&(t_ses2>t0)); plot(t_ses2(ind)-t0,PRAS40_pS183_ses2(ind),'-b','Linewidth',2);
set(gca,'Fontsize',14)
title('D:  PRAS40 pS183','Fontsize',16)
xlabel('Time (min)','Fontsize',16)
legend('High Sestrin','Medium Sestrin','Low Sestrin','Fontsize',14,'Location','northwest')

